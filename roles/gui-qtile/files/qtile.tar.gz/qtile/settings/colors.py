colors = {
#    "background": '#181818',
    "current_line": '#282828',
#    "foreground": '#f8f8f2',
    "comment": '#535453',
#    "black":   '#181818',
#    "red":     '#ab4642',
#    "green":   '#a1b56c',
#    "yellow":  '#f7ca88',
#    "blue":    '#7cafc2',
#    "magenta": '#ba8baf',
#    "cyan":    '#86c1b9',
#    "white":   '#d8d8d8',
    "background": '#000000',
    "foreground": '#fbf1c7',
    "black":   '#21222c',
    "red":     '#ff5555',
    "green":   '#50fa7b',
    "yellow":  '#f1fa8c',
    "blue":    '#bd93f9',
    "magenta": '#ff79c6',
    "cyan":    '#8be9fd',
    "white":   '#f8f8f2',
    #"mood":    '#83a598'
    #"mood":    '#a89984'
    "mood": '#c0c0c0'
}
