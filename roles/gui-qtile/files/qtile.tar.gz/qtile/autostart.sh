#!/bin/bash

## Xrandr
#/home/victor/.screenlayout/xfce_home.sh
# resolution defined  via /etc/lightdm/lightdm.conf => display-setup-script=/home/victor/.screenlayout/xfce_home.sh

# Boot picom
if [ -x "$(command -v picom)" ]; then
#    picom --daemon --experimental-backends &> /dev/null
    picom --daemon &> /dev/null
fi

## Disable power management
#xfce4-power-manager -q
xset -dpms
xset s off
#xset s reset

## Mouse speed
#xinput set-prop 'DaKai 2.4G RX Mouse' 'libinput Accel Speed' 1 &
## Mouse tap
# xinput set-prop "Synaptics s3203" "libinput Tapping Enabled" 1

## Set background
if [ -x "$(command -v feh)" ]; then
    feh --no-fehbg --bg-fill `find /comum/wallpapers -type f | shuf -n1`
fi

## Lauch notification daemon
dunst &

## polkit agent
if [[ ! `pidof xfce-polkit` ]]; then
    /usr/libexec/xfce-polkit &
fi

## Keyboard US Alternawqtive internacional
#setxkbmap us intl
setxkbmap -model abnt -layout us -variant intl

## Enable Super Keys For Menu
ksuperkey -e 'Super_L=Super_L|F1' &
ksuperkey -e 'Super_R=Super_L|F2' &
ksuperkey -e 'Alt_L=dead_acute|c' &

## Switch Shift_L and Caps_Lock buttons
# xmodmap -e 'keycode 66 = Shift_L'
# xmodmap -e 'keycode 50 = Caps_Lock'

## Override Caps_lock to function as Shift_lock
#xmodmap -e 'keycode 66 = Shift_Lock'

## EXTRAS
#volumeicon &
