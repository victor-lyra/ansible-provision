from libqtile.config import Match
from libqtile import layout
from .colors import colors

# Layouts and layout rules


layout_conf = {
    'border_focus': colors['white'],
    'border_normal': colors["black"],
    'border_width': 1,
    'margin': 4
}

layouts = [
    layout.Max(**layout_conf),#
    layout.MonadTall(ratio=0.6, change_ratio=0.05, **layout_conf),#
    layout.MonadWide(**layout_conf),
    #layout.Bsp(**layout_conf),
    #layout.Matrix(columns=2, **layout_conf),
    #layout.RatioTile(**layout_conf),
    #layout.Columns(**layout_conf),
    layout.Stack(stacks=2, **layout_conf),
    #layout.Tile(**layout_conf),#
    #layout.TreeTab(**layout_conf),
    #layout.VerticalTile(**layout_conf),
    #layout.Zoomy(**layout_conf),
    #layout.Floating(margin=0, padding_left = 0, padding_x = 0, padding_y = 0, border_width = 0),
]

floating_layout = layout.Floating(
    border_width=0,
    float_rules=[
        *layout.Floating.default_float_rules,
        Match(wm_class='pavucontrol'),
        Match(wm_class='qalculate-gtk'),
        Match(wm_class='galculator'),
        Match(wm_class='GParted'),
       # Match(wm_class='calcurse'),
        Match(wm_class='confirmreset'),
        Match(wm_class='makebranch'),
        Match(wm_class='maketag'),
        Match(wm_class='ssh-askpass'),
        Match(title='branchdialog'),
        Match(title='pinentry'),

    ],
    border_focus=colors['white']
)

