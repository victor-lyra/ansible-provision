# Qtile cannot directly add personal PATH environment variable:
# 
execs = {
    "kitty": "/home/victor/.local/bin/kitty",
    "color_gpick": "/home/victor/.local/bin/color-gpick",
    "wallpaper": "/home/victor/.local/bin/wallpaper",
    "volume": "/home/victor/.local/bin/volume",
    "takeshot": "/home/victor/.local/bin/takeshot",
    "nmd": "/home/victor/.local/bin/nmd"
}