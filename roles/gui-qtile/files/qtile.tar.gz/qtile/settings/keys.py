import os, subprocess as sp
from libqtile import qtile
from libqtile.config import Key
from libqtile.lazy import lazy

# Switch screens (monitors)
#def switch_screens():
#    @lazy.function
#    def __inner(qtile):
#        i = qtile.screens.index(qtile.current_screen)
#        group = qtile.screens[i - 1].group
#        qtile.current_screen.set_group(group)
#    return __inner

def switch_screens(qtile):
    i = qtile.screens.index(qtile.current_screen)
    group = qtile.screens[i - 1].group
    qtile.current_screen.set_group(group)

def window_to_previous_screen(qtile, switch_group=False, switch_screen=False):
    i = qtile.screens.index(qtile.current_screen)
    if i != 0:
        group = qtile.screens[i - 1].group.name
        qtile.current_window.togroup(group, switch_group=switch_group)
        if switch_screen == True:
            qtile.cmd_to_screen(i - 1)

def window_to_next_screen(qtile, switch_group=False, switch_screen=False):
    i = qtile.screens.index(qtile.current_screen)
    if i + 1 != len(qtile.screens):
        group = qtile.screens[i + 1].group.name
        qtile.current_window.togroup(group, switch_group=switch_group)
        if switch_screen == True:
            qtile.cmd_to_screen(i + 1)

# Qtile keybindings
def show_keys(keys):
    """
    print current keybindings in a pretty way for a rofi/dmenu window.
    """
    key_help = ""
    keys_ignored = (
        "XF86AudioMute",  #
        "XF86AudioLowerVolume",  #
        "XF86AudioRaiseVolume",  #
        "XF86AudioPlay",  #
        "XF86AudioNext",  #
        "XF86AudioPrev",  #
        "XF86AudioStop",
    )
    text_replaced = {
        "mod4": "[Super]",  #
        "control": "[Ctl]",  #
        "mod1": "[Alt]",  #
        "shift": "[Shf]",  #
        "Escape": "Esc",  #
        "Return": "Enter",  #
        "slash": "/",  #
        "bracketright": "]",
        "bracketleft": "[",
    }

    for k in keys:
        if k.key in keys_ignored:
            continue

        mods = ""
        key = ""
        desc = k.desc.title()
        for m in k.modifiers:
            if m in text_replaced.keys():
                mods += text_replaced[m] + " + "
            else:
                mods += m.capitalize() + " + "

            if len(k.key) > 1:
                if k.key in text_replaced.keys():
                    key = text_replaced[k.key]
                else:
                    key = k.key.title()
            else:
                key = k.key

        key_line = "{:<30} {}{}".format(mods + key, k.commands[-1], "\n")
        key_help += key_line

        # debug_print(key_line)  # debug only
    return key_help

mod = "mod4"

# Qtile cannot directly add personal PATH environment variable:
# 
kitty = "/home/victor/.local/bin/kitty" 
color_gpick = "/home/victor/.local/bin/color-gpick"
wallpaper = "/home/victor/.local/bin/wallpaper"
volume = "/home/victor/.local/bin/volume"
takeshot = "/home/victor/.local/bin/takeshot"

keys = [Key(key[0], key[1], *key[2:]) for key in [
    # ------------ Window Configs ------------

    # launchers
    ([mod], "F1", lazy.spawn("/home/victor/.config/rofi/bin/launcher"), "Apps"),
    ([mod], "F2", lazy.spawn("/home/victor/.config/rofi/bin/windows"), "Windows"),
    ([mod], "x",  lazy.spawn("/home/victor/.config/rofi/bin/powermenu"), "Exit: shutdown, reboot, lock, suspend, logout"),
    ([mod], "r", lazy.spawn("/home/victor/.config/rofi/bin/asroot"), "Execute as root apps"),
    ([mod], "s", lazy.spawn("/home/victor/.config/rofi/bin/screenshot"), "Screenshot tasks"),
    ([mod], "n", lazy.spawn("/home/victor/.config/rofi/bin/network"), "Network apps"),
        
    # Terminal
    ([mod], "Return", lazy.spawn(kitty),"kitty terminal"),
    ([mod, "control"], "Return", lazy.spawn("alacritty"), "alacritty terminal"),
    ([mod], 't', lazy.group['scratchpad'].dropdown_toggle('tdrop'), "dropdown kitty terminal"),

    # Switch between windows in current stack pane
    ([mod], "Down", lazy.layout.down(), "Switch windows focus in current stack pane"),
    ([mod], "Up", lazy.layout.up(), "Switch windows focus in current stack pane"),

    # Switch between screens (monitors)
    #([mod], "w", switch_screens(), "Switch windows focus in current stack pane"),
    ([mod], "w", lazy.function(switch_screens), "Switch screens"),

    # switch between groups
    ([mod, "control"], "Left", lazy.screen.prev_group(skip_empty=True), "Go to previous group"),
    ([mod, "control"], "Right", lazy.screen.next_group(skip_empty=True), "Go to next group"),

    # Change window sizes (MonadTall)
    ([mod], "equal", lazy.layout.grow(), "Resize windows (Monad layout)"),
    ([mod], "minus", lazy.layout.shrink(), "Resize windows (Monad layout)"),
    
    # Move windows
    ([mod, "mod1"], "Return", lazy.layout.flip(), "Flip windows position (Monad layout)"),
    ([mod, "mod1"], "Left", lazy.function(window_to_previous_screen, switch_screen=True), "Move window to previous screen"),
    ([mod, "mod1"], "Right", lazy.function(window_to_next_screen, switch_screen=True), "Move window to next screen"),

    # keyboard switch
    ([mod], "space", lazy.widget["keyboardlayout"].next_keyboard(), "Switch to next keyboard layout"),

    # Toggle
    ([mod, "control"], "f", lazy.window.toggle_floating(), "Toggle floating"),
    ([mod, "control"], "u", lazy.window.toggle_fullscreen(), "Toggle fullscreen"),

    # Move windows up or down in current stack
    ([mod, "mod1"], "Up", lazy.layout.shuffle_down(), "Move windows up in current stack"),
    ([mod, "mod1"], "Down", lazy.layout.shuffle_up(), "Move windows down in current stack"),

    # Toggle between different layouts
    ([mod], "Tab", lazy.next_layout(), "Toggle between different layouts"),

    # Kill window
    ([mod], "c", lazy.window.kill(), "Close window"),
    ([mod], "q", lazy.window.kill(), "Close window"),

    # Switch focus of monitors
    ([mod], "Left", lazy.next_screen(), "Switch focus between monitors"),
    ([mod], "Right", lazy.prev_screen(), "Switch focus between monitors"),

    # Restart Qtile
    # ([mod, "control"], "r", lazy.reload_config(), "Qtile soft reload"),
    ([mod, "mod1"], "r", lazy.reload_config(), "Qtile restart"),
    ([mod, "mod1"], "q", lazy.shutdown(), "Qtile shutdown"),

    # ------------ App Configs ------------
    # Editor
    ([mod], "e", lazy.spawn("subl"), "Sublime text editor"),
    # Browser
    ([mod], "b", lazy.spawn("vivaldi"), "Vivaldi browser"),
    # File Explorer
    ([mod], "f", lazy.spawn("Thunar"), "Thunar file manager"),
    # color-pick
    ([mod], "p", lazy.spawn(color_gpick), "Color pick"),

    # ------------ System Configs ------------

    ([mod], "l", lazy.spawn("betterlockscreen --lock dim"), "Lock screen"),
    ([mod, "control"], "w", lazy.spawn(wallpaper), "Draw a new wallpaper"),

    # ------------ Hardware Configs ------------

    # Volume
    ([mod], "bracketright", lazy.spawn(volume + " --inc"), "Volume up"),
    ([mod], "bracketleft", lazy.spawn(volume + " --dec"), "Volume down"),
    # Screen
    ([mod], "Print", lazy.spawn(takeshot + " --clip"), "Screenshot to clipboard"),
    ([mod, "shift"], "4", lazy.spawn(takeshot + " --clip"), "Screenshot to clipboard"), # K3 Keychron special combo

    # Calendar (workaround)
    ([], "F12", lazy.group['scratchpad'].dropdown_toggle('calendar'), "dropdown calendar"),

    ([], "XF86AudioLowerVolume", lazy.spawn( "pactl set-sink-volume @DEFAULT_SINK@ -5%")),
    ([], "XF86AudioRaiseVolume", lazy.spawn("pactl set-sink-volume @DEFAULT_SINK@ +5%")),
    ([], "XF86AudioMute", lazy.spawn("pactl set-sink-mute @DEFAULT_SINK@ toggle")),

    # Brightness
    # ([], "XF86MonBrightnessUp", lazy.spawn("brightnessctl set +10%")),
    # ([], "XF86MonBrightnessDown", lazy.spawn("brightnessctl set 10%-")),
]]

keys.extend([Key([mod], "slash", lazy.spawn("sh -c 'echo \"" + show_keys(keys) + "\" | rofi -dmenu -theme android_notification -i -fuzzy -mesg \"Keyboard shortcuts\"'"), desc="Print keyboard bindings"),])
