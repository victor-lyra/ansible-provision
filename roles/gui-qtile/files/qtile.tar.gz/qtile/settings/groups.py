# Qtile workspaces

from libqtile.config import Key, Group, Match, ScratchPad, DropDown
from libqtile.lazy import lazy
from .keys import mod, keys
from .execs import execs


# Get the icons at https://www.nerdfonts.com/cheat-sheet (you need a Nerd Font)
# Icons:
# nf-fa-firefox,
# nf-fae-python,
# nf-dev-terminal,
# nf-fa-code,
# nf-oct-git_merge,
# nf-linux-docker,
# nf-mdi-image,
# nf-mdi-layers

# Groups
groups = [
    Group(name='1', label="1", layout="monadtall"),
    Group(name='2', label="2", layout="monadtall"),
    Group(name='3', label="3", layout="monadtall"),
    Group(name='4', label="4", layout='monadtall'),
    Group(name='5', label="5", layout='monadtall'),
    Group(name='6', label="6", layout="monadtall"),
    Group(name='7', label="7", layout="monadtall"),
    Group(name='8', label="8", layout='monadtall'),
    Group(name='9', label="9", layout='monadtall'),
]

for i in groups:
    keys.extend([
        Key([mod], i.name, lazy.group[i.name].toscreen()),

        Key([mod, "mod1"], i.name, 
          lazy.window.togroup(i.name),
          lazy.group[i.name].toscreen()),
    ])
    
# Scratchpad
groups.append(
    ScratchPad(name="scratchpad", dropdowns=[
        # define a drop down terminal.
        # it is placed in the upper third of screen by default.
        DropDown("tdrop", execs['kitty'], warp_pointer=True,opacity=0.95, x=0, y=0, width=1),
        DropDown("calendar", "zenity --calendar", warp_pointer=True,opacity=0.95, x=0.8, y=0, width=0.20) ])
)